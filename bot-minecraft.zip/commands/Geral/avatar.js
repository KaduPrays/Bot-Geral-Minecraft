const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');

module.exports = {
    name: "avatar",
    aliases: ['foto'],
    run: async(client, message, args) => {

    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author; 
    let avatar = user.avatarURL({ dynamic: true, format: 'png', size: 1024 });

    let embed = new DrickAPI.MessageEmbed()

    .setAuthor(`${user.username}`, "https://cdn.discordapp.com/emojis/770851436749258772.gif?v=1")
    .setImage(avatar)
    .setColor(colors.none)
       
    message.channel.send(`${user}`, embed)
    
    }
}