const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');

module.exports = {
  name: "ajuda",
  aliases: ['help'],
  run: async(client, message, args) => {

  const ajuda = new Discord.MessageEmbed()

  .setAuthor(`💻 Lista de Comandos`)
  .setDescription(`• 📍 Prefixo: \`${config.prefix}\`

  🏠 - **Menu Principal**
  🔎 - **Utilitários**
  📚 - **Moderação**
  💵 - **Economia**`)
  .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 4096 }))
  .setColor(colors.none)

  message.channel.send(ajuda).then(msg => {

  msg.react('🏠').then(r => {
  msg.react('🔎').then(r => {
  msg.react('📚').then(r => {
  msg.react('💵').then(r => {

  const inicioFilter = (reaction, user) => reaction.emoji.name === '🏠' && user.id === message.author.id;
  const modFilter = (reaction, user) => reaction.emoji.name === '📚' && user.id === message.author.id;
  const ecoFilter = (reaction, user) => reaction.emoji.name === '💵' && user.id === message.author.id;
  const utilsFilter = (reaction, user) => reaction.emoji.name === '🔎' && user.id === message.author.id;

  const inicio = msg.createReactionCollector(inicioFilter);
  const mod = msg.createReactionCollector(modFilter);
  const eco = msg.createReactionCollector(ecoFilter);
  const utils = msg.createReactionCollector(utilsFilter);
  
  let embed1 = new Discord.MessageEmbed()

  .setDescription(`🔒 - **__ADMINISTRAÇÃO__**:\n
  • **${config.prefix}lock** - Travar algum canal do servidor.
  • **${config.prefix}unlock** - Destravar algum canal do servidor.
  • **${config.prefix}say** - Falar usando o client.
  • **${config.prefix}embed** - Faz um anúncio.`)
  .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 4096 }))
  .setColor(colors.none)
  
  let embed2 = new Discord.MessageEmbed()

  .setDescription(`🔧 - **__UTILITÁRIOS__**:\n
  • **${config.prefix}ajuda** - Visualizar os meus comandos.
  • **${config.prefix}avatar** - Visualizar o avatar de algum membro.
  • **${config.prefix}ping** - Veja a latência do client.
  • **${config.prefix}serverinfo** - Visualizar as informações do servidor.
  • **${config.prefix}perfil** - Visualizar as informações sobre algum membro.`)
  .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 4096 }))
  .setColor(colors.none)

  let embed3 = new Discord.MessageEmbed()

  .setDescription(`💵 - **__ECONOMIA__**:\n
  • **${config.prefix}money** - Mostra a quantidade de money.
  • **${config.prefix}work** - Trabalhe para ganhar mais money.
  • **${config.prefix}rank** - Mostra o rank monetário do grupo.
  • **${config.prefix}pay** - Envia uma quantia de dinheiro.
  • **${config.prefix}rob** - Roube money de alguma pessoa.
  • **${config.prefix}dep** - Deposite o dinheiro e evite ser roubado.
  • **${config.prefix}daily** - Pegue sua recompensa diária.
  • **${config.prefix}with** - Realize um saque do banco.`)
  .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 4096 }))
  .setColor(colors.none)

  inicio.on('collect', r2 => {
    r2.users.remove(message.author.id)
    msg.edit(ajuda)
  })

  mod.on('collect', r2 => {
    r2.users.remove(message.author.id)
    msg.edit(embed1)
  })

  utils.on('collect', r2 => {
    r2.users.remove(message.author.id)
    msg.edit(embed2)
  })

  eco.on('collect', r2 => {
    r2.users.remove(message.author.id)
    msg.edit(embed3)
  })

  })
  })
  })
  })
  })
  }
}