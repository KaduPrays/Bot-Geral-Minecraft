const DrickAPI = require('discord.js');
const DrickConfig = require('../../config.json');
const DrickColors = require('../../colors.json');

module.exports = {
  name: "mchead",
  aliases: ['head'],
  run: async(client, message, args) => {

  const player = args[0]
  const mchead = new DrickAPI.MessageEmbed()

  .setAuthor(`Aqui está a cabeça de ${player}!`)
  .setURL(`https://mc-heads.net/head/${player}/500`)
  .setImage(`https://mc-heads.net/head/${player}/140`)
  .setColor(DrickColors.none)
    
  message.channel.send(mchead)

  }	
}