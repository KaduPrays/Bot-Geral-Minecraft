const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const moment = require('moment');
moment.locale('pt-BR');

module.exports = {
    name: "serverinfo",
    aliases: ['svinfo'],
    run: async(client, message, args) => {

    let totalmembros = message.guild.memberCount;
    let canaistexto = message.guild.channels.cache.filter(a => a.type === "text").size;
    let canaisvoz = message.guild.channels.cache.filter(a => a.type === "voice").size;

    const embed = new Discord.MessageEmbed()

    .setTitle(message.guild.name)
    .setDescription(`> 👑 **|** Dono: ${message.guild.owner}
    > 📍 **|** ID: ${message.guild.id}
    > 😄 **|** Emojis: (${message.guild.emojis.cache.size})
    > 📃 **|** Cargos: (${message.guild.roles.cache.size})
    > 
    > 📑 **|** Canais: (${canaistexto+canaisvoz})
    > 🔊 **|** Voz: ${canaisvoz}
    > 💬 **|** Texto: ${canaistexto}
    > 
    > 🕒 **|** Criado em: ${moment(message.guild.createdAt).format('LLL')}
    > 🌎 **|** Região: ${message.guild.region.charAt(0).toUpperCase() + message.guild.region.slice(1)}
    > 👥 **|** Membros: (${totalmembros})`)
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 4096 }))
    .setColor(colors.none)

    message.channel.send(`${message.author}`)
    message.channel.send(embed)

  }
}