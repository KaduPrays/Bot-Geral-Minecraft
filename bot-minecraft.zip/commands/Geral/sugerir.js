const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');

module.exports = {
    name: "sugerir",
    aliases: ['sugestão'],
    run: async(client, message, args) => {

    let titleMsg = await message.channel.send(`Qual é o título da sua sugestão?`);

    const filter = m => m.author.id === message.author.id;
    message.channel.awaitMessages(filter, {max: 1}).then(async collected => {
            
    let title = collected.first();
    title.delete();
    titleMsg.delete();

    let bodyMsg = await message.channel.send(`Qual será a descrição de sua sugestão?`);

    message.channel.awaitMessages(filter, {max: 1}).then(collected => {
                
    let body = collected.first();
    body.delete();
    bodyMsg.delete();

    let avatar = message.author.avatarURL({ dynamic: true, format: 'png', size: 1024 });
    let embed = new Discord.MessageEmbed()

    .setTitle(title.content)
    .setAuthor(message.author.username, avatar)
    .setDescription(body.content)
    .setColor(colors.none)

    let guild = message.guild.channels.cache.find(ch => ch.name === DrickConfig.Sys);
    guild.send(embed).then(msg => {
        
    msg.react('✅')
    msg.react('❌')
    
    })
    })
    })
    }
}