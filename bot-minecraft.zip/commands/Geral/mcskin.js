const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');

module.exports = {
    name: "mcskin",
    aliases: ['skin'],
    run: async(client, message, args) => {

    const player = args[0]
    const mcbody = new Discord.MessageEmbed()

    .setAuthor(`Aqui está a skin de ${player}!`)
    .setURL(`https://mc-heads.net/body/${player}/500`)
    .setImage(`https://mc-heads.net/body/${player}/500`)
    .setColors(colors.none)
    
    message.channel.send(mcbody)
    
    }
}