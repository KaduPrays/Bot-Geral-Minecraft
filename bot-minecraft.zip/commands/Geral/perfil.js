const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const moment = require('moment');
moment.locale('pt-BR');

module.exports = {
    name: "perfil",
    aliases: ['userinfo'],
    run: async(client, message, args) => {

    let user = client.users.cache.get(args-[0]) || message.mentions.users.first() ||  message.author;

    let statusmebro;

    if(user.presence.status === "dnd") statusmebro = `**Ocupado**`;
    if(user.presence.status === "idle") statusmebro = `**Ausente**`;
    if(user.presence.status === "offline") statusmebro = `**Offline**`;
    if(user.presence.status === "online") statusmebro = `**Online**`;

    let member = message.guild.member(user);

    const embed = new Discord.MessageEmbed()

    .setAuthor(`👤 Informações de ${user.tag}`)
    .setDescription(`\n> 🎓 **|** Apelido: ${member.nickname !== null ? `${member.nickname}` : '`Nenhum`'}` +
    `\n> ⚙ **|** Tag: \`#${user.discriminator}\`` +
    `\n> 🔧 **|** ID: \`${user.id}\`` +
    `\n> \n> 🕒 **|** Conta criada: ${moment(user.createdAt).format('LL')}` +
    `\n> 📅 **|** Entrou aqui: ${moment(member.joinedAt).format('LL')}` +
    `\n> 📍 **|** Status: ${statusmebro}`)
    .setThumbnail(message.author.displayAvatarURL({ dynamic: true, format: 'png', size: 1024 }))
    .setColor(colors.none)
            
    message.channel.send(`${user}`, embed)

    }
}