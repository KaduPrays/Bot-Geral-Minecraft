const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const db = require('quick.db');
const ms = require('parse-ms');

module.exports = {
    name: "money",
    aliases: ['coins'],
    run: async(client, message, args) => {

    let user = client.users.cache.get(args-[0]) || message.mentions.users.first() ||  message.author;

    let coins = db.fetch(`coins_${message.guild.id}_${user.id}`)
    if(coins === null) coins = 0;

    let banco = db.fetch(`banco_${message.guild.id}_${user.id}`);
    if(banco == null) banco = 0;

    const embed = new Discord.MessageEmbed()

    .setAuthor('👷 Trabalho')
    .setThumbnail("https://img.icons8.com/bubbles/2x/money.png")
    .setDescription(`> Estou listando abaixo o saldo da conta: ${user}.`)
    .addField('💸 Coins', coins, true)
    .addField('🏛 Banco', banco, true)
    .addField('🤑 Total', banco+coins, true)
    .setColor(colors.none)

    message.channel.send(embed)

    }   
}