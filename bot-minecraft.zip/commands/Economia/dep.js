const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const db = require('quick.db');
const ms = require('parse-ms');

module.exports = {
    name: "dep",
    aliases: ['depositar'],
    run: async(client, message, args) => {

    let member = db.fetch(`coins_${message.guild.id}_${message.author.id}`)
    if(member == null) member = 0;

    let banco = db.fetch(`banco_${message.guild.id}_${message.author.id}`)
    if(banco == null) banco = 0;

    let coins = db.fetch(`coins_${message.guild.id}_${message.author.id}`)
    if(coins === null) coins = 0;

    let embed2 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Coloque o valor do deposito!`)
    .setColor(colors.red)
  
    if(!args[0]) {
        return message.channel.send(`${message.author}`, embed2)
    }

    let embed4 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Você não coins suficiente para realizar o deposito!`)
    .setColor(colors.red)

    if(member < args[0]) {
        return message.channel.send(`${message.author}`, embed4)
    }

    let embed5 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Você tem que colocar um valor maior que **0** para realizar o deposito!`)
    .setColor(colors.red)

    if(args[0] < 0) {
        return message.channel.send(`${message.author}`, embed5)
    }

    let embed6 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Você tem que colocar um valor numerico para realizar o deposito!`)
    .setColor(colors.red)

    if(isNaN(args[0])) {
        return message.channel.send(`${message.author}`, embed6)
    }

    let embed7 = new Discord.MessageEmbed()
    
    .setAuthor('👷 Trabalho')
    .setDescription(`> O usuário: ${message.author} depositou: **${args[0]}** coins.`)
    .addField('💸 Coins', coins-args[0], true)
    .addField('🏛 Banco', banco, true)
    .addField('🤑 Total', coins+banco, true)
    .setColor(colors.none)

    message.channel.send(`${message.author}`, embed7)

    db.add(`banco_${message.guild.id}_${message.author.id}`, args[0])
    db.subtract(`coins_${message.guild.id}_${message.author.id}`, args[0])
    
    }
}