const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const db = require('quick.db');
const ms = require('parse-ms');

module.exports = {
    name: "rank",
    aliases: ['leaderboard'],
    run: async(client, message, args) => {

    let bank = db.all().filter(data => data.ID.startsWith(`banco_${message.guild.id}`)).sort((a, b) => b.data - a.data);
    let bank1;
    
    if(bank.length > 10) {
        bank1 = 10
    } else {
        bank1 = bank.length
    }
    
    let content = "";

    for (let i = 0; i < bank1; i++) {
        let user = client.users.cache.get(bank[i].ID.split('_')[2])

        content += `> 🏅 **${i+1}º** : ${user} - Coins: (R$**${bank[i].data}**)\n`
    }

    const embed = new Discord.MessageEmbed()

    .setAuthor('📚 Ranking Monetário')
    .setDescription(`${content}`)
    .setThumbnail('https://cdn1.iconfinder.com/data/icons/game-design-butterscotch-vol-1/256/Leader-512.png')
    .setColor(colors.none)

    message.channel.send(`${message.author}`, embed)
    
    }
}