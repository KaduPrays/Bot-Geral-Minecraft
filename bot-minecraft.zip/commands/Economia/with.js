const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const db = require('quick.db');
const ms = require('parse-ms');

module.exports = {
    name: "with",
    aliases: ['sacar'],
    run: async(client, message, args) => {

    let member = db.fetch(`banco_${message.guild.id}_${message.author.id}`);

    let embed1 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Coloque o valor do saque!`)
    .setColor(colors.red)
  
    if (!args[0]) {
        return message.channel.send(`${message.author}`, embed1)
    }

    let embed2 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Você não dinheiro no banco o suficiente para realizar o saque!`)
    .setColor(colors.red)

    if (member < args[0]) {
        return message.channel.send(`${message.author}`, embed2)
    }

    let embed3 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Você tem que colocar um valor maior que **0** para realizar o saque!`)
    .setColor(colors.red)

    if(args[0] < 0) {
        return message.channel.send(`${message.author}`, embed5)
    }

    let embed4 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Você tem que colocar um valor numerico para realizar o saque!`)
    .setColor(colors.red)

    if(isNaN(args[0])) {
        return message.channel.send(`${message.author}`, embed4)
    }

    let embed6 = new Discord.MessageEmbed()

    .setAuthor('💸 Saque')
    .setDescription(`> Você sacou no banco um valor de **R$${args[0]}**.`)
    .setColor(colors.green)

    message.channel.send(`${message.author}`, embed6)

    db.add(`coins_${message.guild.id}_${message.author.id}`, args[0])
    db.subtract(`banco_${message.guild.id}_${message.author.id}`, args[0])

    }
}