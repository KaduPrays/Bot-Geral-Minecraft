const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const db = require('quick.db');
const ms = require('parse-ms');
const moment = require('moment');

module.exports = {
    name: "work",
    aliases: ['trabalhar'],
    run: async(client, message, args) => {

    let user = message.author;
    let author = await db.fetch(`work_${message.guild.id}_${user.id}`)
    let timeout = 600000;

    let coins = db.fetch(`coins_${message.guild.id}_${user.id}`)
    if(coins === null) coins = 0;

    let banco = db.fetch(`banco_${message.guild.id}_${user.id}`);
    if(banco == null) banco = 0;
    
    if(author !== null && timeout - (Date.now() - author) > 0) {
        
    let time = ms(timeout - (Date.now() - author))
    
    let timeEmbed = new DrickAPI.MessageEmbed()

    .setAuthor('💔 Ops! algo saiu errado')
    .setDescription(`Você deve aguardar **${time.minutes} minuto(s)** e **${time.seconds} segundo(s)**  para trabalhar novamente.`)
    .setColor(colors.red)

    message.channel.send(`${user}`, timeEmbed)
    
    } else {

    let replies = ['Programador','Construtor','Agricultor','Garçom','Mecanico','Cozinheiro', 'Vendedor','Barqueiro','YouTuber','Padeiro']
        
    let result = Math.floor((Math.random() * replies.length))
    let amount = Math.floor(Math.random() * 5000) + 1;
    
    let embed = new db.MessageEmbed()

    .setAuthor('👷 Trabalho')
    .setDescription(`> Você trabalhou como: **${replies[result]}** e ganhou **${amount}** coins.`)
    .addField('💸 Coins', coins+amount, true)
    .addField('🏛 Banco', banco, true)
    .addField('🤑 Total', banco+coins+amount, true)
    .setFooter(moment().format("L") + " - " + moment().format('LTS') + " - " + user.username)
    .setColor(colors.none)

    message.channel.send(`${user}`, embed)
    
    db.add(`coins_${message.guild.id}_${user.id}`, amount)
    db.set(`work_${message.guild.id}_${user.id}`, Date.now())

    }
    }
}