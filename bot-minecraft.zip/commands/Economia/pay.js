const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const db = require('quick.db');
const ms = require('parse-ms');

module.exports = {
    name: "pay",
    aliases: ['pagar'],
    run: async(client, message, args) => {

    let user = message.mentions.members.first() 
    let member = db.fetch(`coins_${message.guild.id}_${message.author.id}`)

    let embed1 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Mencione alguem para pagar!`)
    .setColor(colors.red)

    if(!user) {
        return message.channel.send(`${message.author}`, embed1)
    }

    let embed2 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Coloque o valor do pagamento!`)
    .setColor(colors.red)
  
    if(!args[1]) {
        return message.channel.send(`${message.author}`, embed2)
    }

    let embed4 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Você não dinheiro suficiente para realizar o pagamento!`)
    .setColor(colors.red)

    if(member < args[1]) {
        return message.channel.send(`${message.author}`, embed4)
    }

    let embed5 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Você tem que colocar um valor maior que **0** para realizar o pagamento!`)
    .setColor(colors.red)

    if(args[1] < 0) {
        return message.channel.send(`${message.author}`, embed5)
    }

    let embed7 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`> Você tem que colocar um valor numerico para realizar o pagamento!`)
    .setColor(colors.red)

    if(isNaN(args[1])) {
        return message.channel.send(`${message.author}`, embed7)
    }
    
    let embed6 = new Discord.MessageEmbed()

    .setAuthor('💵 Pagamento')
    .setDescription(`> Você pagou o ${user} com **R$${args[1]}**.`)
    .setColor(colors.green)

    message.channel.send(`${message.author}`, embed6)
    
    db.add(`coins_${message.guild.id}_${user.id}`, args[1])
    db.subtract(`coins_${message.guild.id}_${message.author.id}`, args[1])

    }
}