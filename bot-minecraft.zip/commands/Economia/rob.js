const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const db = require('quick.db');
const ms = require('parse-ms');

module.exports = {
    name: "rob",
    aliases: ['roubar'],
    run: async(client, message, args) => {
	
    let autor = message.author;
    let user = message.mentions.users.first();

    let embed1 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Você tem que mencionar um membro para realizar seu roubo!`)
    .setColor(colors.red)
    
    if(!user) {
        return message.channel.send(`${message.author}`, embed1)
    }

    let embed2 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Você não pode se auto-roubar!`)
    .setColor(colors.red)

    if(user.id == autor.id) {
        return message.channel.send(`${message.author}`, embed2)
    }

    let user_money = await db.fetch(`coins_${message.guild.id}_${user.id}`)
    if(user_money == null) user_money = 0;

    let autor_money = await db.fetch(`coins_${message.guild.id}_${autor.id}`)
    if(autor_money == null) autor_money = 0;

    let user_bank = await db.fetch(`banco_${message.guild.id}_${user.id}`)
    if(user_bank == null) user_bank = 0;

    let autor_bank = await db.fetch(`banco_${message.guild.id}_${autor.id}`)
    if(autor_bank == null) autor_bank = 0;
        
    let embed3 = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Você não pode roubar alguem que não possui dinheiro!`)
    .setColor(colors.red)

    if(user_money <= 0) {
        return message.channel.send(`${message.author}`, embed3)
    }

    let timeout = 86400000;

    let daily = await db.fetch(`rob_${message.guild.id}_${autor.id}`)
    if(daily !== null && timeout - (Date.now() - daily) > 0) {

    let time = ms(timeout - (Date.now() - daily));
  
    let timeEmbed = new Discord.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Você deve aguardar **${time.hours} hora(s)** e **${time.minutes} minuto(s)** para roubar novamente.`)
    .setColor(colors.red)

    message.channel.send(`${autor}`, timeEmbed);
			
    } else {
            
    let amount = Math.floor(Math.random() * user_money) + 1;
            
    let moneyEmbed = new Discord.MessageEmbed()

    .setAuthor('🕵 Roubo')
    .setDescription(`O usuário: ${message.author} roubou **${amount} coins** do usuário: ${user}.`)
    .addField('💸 Coins', amount+autor_money, true)
    .addField('🏛 Banco', autor_bank, true)
    .addField('🤑 Total', autor_bank+autor_money, true)
    .setColor(colors.none)
            
    message.channel.send(`${autor}`, moneyEmbed)
            
    db.subtract(`coins_${message.guild.id}_${user.id}`, amount);
    db.add(`coins_${message.guild.id}_${autor.id}`, amount);
    db.set(`rob_${message.guild.id}_${autor.id}`, Date.now());
    
    }
    }
}