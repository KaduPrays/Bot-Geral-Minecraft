const DrickAPI = require('discord.js');
const DrickConfig = require('../../config.json');
const DrickColors = require('../../colors.json');
const DrickTime = require('moment');

module.exports = {
    name: "kick",
    aliases: ['expulsar'],
    run: async(client, message, args) => {

    var membro = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    const embederro = new DrickAPI.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Use: ${DrickConfig.Prefix}kick (usermention) (motivo)`)
    .setColor(DrickColors.red)

    if(!membro) return message.channel.send(embederro)
    if(membro === message.member) return message.reply('você não pode se expulsar do grupo!');

    var motivo = args.slice(1).join(" ");

    if(!motivo) return message.channel.send(embederro)
    if(!message.member.hasPermission("KICK_MEMBERS")) return message.reply('você não possui permissão para executar este comando!');

    const kick = new DrickAPI.MessageEmbed()

    .setAuthor('📕 Punição')
    .setDescription(`> Estou listando abaixo os dadas da punição do membro: ${membro}

    ▫️ Tipo: **Kick**
    ▫️ Autor: ${message.author}
    ▫️ Punido: ${membro}
    ▫️ Motivo: ${motivo}
    ▫️ Tempo: Indeterminado`)
    .setColor(DrickColors.none)
    .setFooter("A punição foi aplicada "+ DrickTime().format("LLL") +".")

    const embedsucesso = new DrickAPI.MessageEmbed()

    .setAuthor('💚 Ebah! Tudo certo.')
    .setDescription(`O usuário ${membro} foi kickado.`)
    .setColor(DrickColors.green)

    message.channel.send(embedsucesso)
    client.channels.cache.get(DrickConfig.Logs).send(kick)
    membro.kick()

    }
}