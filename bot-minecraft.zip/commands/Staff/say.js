const DrickAPI = require('discord.js');
const DrickConfig = require('../../config.json');
const DrickColors = require('../../colors.json');

module.exports = {
    name: "say",
    aliases: ['falar'],
    run: async(client, message, args) => {

    if(!message.member.permissions.has("MANAGE_MESSAGES"))
    return message.reply("você não tem permissão para executar este comando!");
    
    var fala = args.slice(1).join(" ");

    const embederror = new DrickAPI.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Use: ${config.Prefix}say (canalmention) (mensagem)`)
    .setColor(DrickColors.red)

    if(!fala) return message.channel.send(embederror)
    
    var canal = message.mentions.channels.first() || message.guild.channels.cache.get(args[0])

    if(!canal) return message.channel.send(embederror)
    message.delete()
    
    canal.send(fala)
    
    }
}