const DrickAPI = require('discord.js');
const DrickConfig = require('../../config.json');
const DrickColors = require('../../colors.json');

module.exports = {
  name: "limpar",
  aliases: ['clear'],
  run: async(client, message, args) => {

  if(!message.member) return
  
  if(!message.member.hasPermission('MANAGE_CHANNELS'))
  return message.channel.send(`${message.author}, você não possui permissão para executar esse comando!`).then(msg => msg.delete(6000));

  var limit = 100
  if(args.length === 1) {
  limit = parseInt(args[0])
  } else {
    
  const embederror = new DrickAPI.MessageEmbed()

  .setAuthor('💔 Ops! Algo saiu errado.')
  .setDescription(`Use: ${config.Prefix}limpar (quantidade)`)
  .setColor(DrickColors.red)

  if(!args[0]) return message.channel.send(embederror).then(message => setTimeout(() => message.delete(), 8000))
      
  return message.reply(comousar)
  
  }

  if(!Number.isInteger(limit)) return message.channel.send(embederror).then(message => setTimeout(() => message.delete(), 8000))
  limit++
  limit = Math.min(limit, 99)
  
  message.channel.bulkDelete(limit).then(messages => {

  const embed = new DrickAPI.MessageEmbed()

  .setAuthor(`💚 Ebah! Tudo certo.`)
  .setDescription(`O chat foi limpo! Foram apagadas **${messages.size}** mensagens.`)
  .setColor(DrickColors.green)

  message.channel.send(embed).then(message => setTimeout(() => message.delete(), 8000))
  
  })
  }
  
}