const DrickAPI = require('discord.js');
const DrickConfig = require('../../config.json');
const DrickColors = require('../../colors.json');
const ms = require('ms');
const moment = require('moment');

module.exports = {
  name: "tempmute",
  aliases: ['tp'],
  run: async(client, message, args) => {
  
  if(message.guild === null) return;

  var tomute = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

  const embederror = new DrickAPI.MessageEmbed()

  .setAuthor('💔 Ops! Algo saiu errado.')
  .setDescription(`Use: ${DrickConfig.Prefix}tempmute (usermention) (duração) (motivo)`)
  .setColor(DrickColors.red)

  if(!tomute) return message.channel.send(embederror)
  if(tomute === message.member) return message.reply('você não pode mutar a si mesmo!')
  
  var motivo = args.slice(2).join(" ")

  if(!motivo) return message.channel.send(embederror)
  if(!message.member.hasPermission("MUTE_MEMBERS")) return message.reply('você não possui permissão para executar este comando!');

  let muterole = message.guild.roles.cache.get("729896058607632508");
  
  let mutetime = args[1];

  if(!mutetime) return message.channel.send(embederror)

  await(tomute.roles.add(muterole.id));

  const embed = new DrickAPI.MessageEmbed()

  .setAuthor('💚 Ebah! Tudo certo.')
  .setDescription(`O usuário <@${tomute.id}> foi mutado por **${ms(ms(mutetime))}**.`)
  .setColor(DrickColors.green)

  const tempmute = new DrickAPI.MessageEmbed()

  .setAuthor('📕 Punição')
  .setDescription(`> Estou listando abaixo os dadas da punição do membro: <@${tomute.id}>

  ▫️ Tipo: **Mute**
  ▫️ Autor: ${message.author}
  ▫️ Punido: <@${tomute.id}>
  ▫️ Motivo: ${motivo}
  ▫️ Tempo: ${ms(ms(mutetime))}`)
  .setColor(DrickColors.none)
  .setFooter("A punição foi aplicada "+ DrickData().format("LLL") +".")
  
  message.channel.send(embed)
  let guild = message.guild.channels.cache.find(ch => ch.name === DrickConfig.Logs)
  guild.send(tempmute).catch(O_o=>{})

  setTimeout(function() {
  tomute.roles.remove(muterole.id)
  }, ms(mutetime))
  }
}