const Discord = require('discord.js');
const config = require('../../config.json');
const colors = require('../../colors.json');
const DrickTime = require('moment');

module.exports = {
    name: "ban",
    aliases: ['banir'],
    run: async(client, message, args) => {

    var membro = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    const embederror = new DrickAPI.MessageEmbed()

    .setAuthor('💔 Ops! Algo saiu errado.')
    .setDescription(`Use: ${DrickCore.Prefix}ban (usermention) (motivo)`)
    .setColor(DrickColors.red)

    if(!membro) return message.channel.send(embederror)
    if(membro === message.member) return message.reply('você não pode banir a si mesmo!')

    var motivo = args.slice(1).join(" ")

    if(!motivo) return message.channel.send(embederror)
    if(!message.member.hasPermission("BAN_MEMBERS")) return message.reply('você não possui permissão para executar este comando!');

    const ban = new DrickAPI.MessageEmbed()

    .setAuthor('📕 Punição')
    .setDescription(`> Estou listando abaixo os dadas da punição do membro: ${membro}

    ▫️ Tipo: **Ban**
    ▫️ Autor: ${message.author}
    ▫️ Punido: ${membro}
    ▫️ Motivo: ${motivo}
    ▫️ Tempo: Indeterminado`)
    .setColor(DrickColors.none)
    .setFooter("A punição foi aplicada "+ DrickTime().format("LLL") +".")

    const embed2 = new DrickAPI.MessageEmbed()

    .setAuthor('💚 Ebah! Tudo certo.')
    .setDescription(`O usuário ${membro} foi banido.`)
    .setColor(DrickColors.green)

    message.channel.send(embed2)
    
    let guild = message.guild.channels.cache.find(ch => ch.name === DrickCore.Logs);
    guild.send(ban).catch(O_o=>{});

    const banido = DrickAPI.MessageEmbed()

    .setAuthor('🚔 Banido')
    .setDescription(`> Você foi banido da **RedeDrick**.`)
    .setColor(DrickColors.red)
    
    membro.send(banido)
    membro.ban()

    }
}