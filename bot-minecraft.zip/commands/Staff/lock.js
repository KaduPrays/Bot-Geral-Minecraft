const Discord = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: "lock",
    aliases: ['chatoff'],
    run: async(client, message, args) => {

    if(!message.guild.members.get(message.author.id).hasPermission('ADMINISTRATOR')) {
        return message.reply(`você não tem permissão para utilizar esse comando!`)
    }
    
    var da = message.guild.roles.find("name","@everyone")
    message.channel.overwritePermissions(da, {
        SEND_MESSAGES: false
    })
    
    message.channel.send(`O canal ${message.channel} foi **desativado** pelo ` + message.author)
    
    }
}