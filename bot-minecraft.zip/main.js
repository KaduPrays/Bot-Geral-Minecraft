const Discord = require('discord.js');
const config = require('./config.json');
const colors = require('./colors.json');
const client = new Discord.Client();
const fs = require('fs');

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

["command"].forEach(handler => {
    require(`./handlers/${handler}`)(client);
});

client.on('message', async (message, user) => {
    if(message.author.bot || message.channel.type === "dm") return;
    if(!message.guild) return;
    if(!message.channel.send) return;

    let messageArray = message.content.split(" ");
    let cmd = messageArray[0].toLowerCase();
    let args = messageArray.slice(1);
    if(!message.content.startsWith(config.prefix)) return;

    let command = client.commands.get(cmd.slice(config.prefix.length)) || client.commands.get(client.aliases.get(cmd.slice(config.prefix.length)));
    if(command) command.run(client, message, args);
    if(!command) return null
});

client.on("guildMemberAdd", async (member) => {

    const guild = client.guilds.cache.get(config.guild);
    var memberCount = guild.members.cache.filter(member => !member.user.bot).size;

    const embed = new Discord.MessageEmbed()
    
    .setAuthor(`👋 Bem-vindo(a) ${member.user.tag}`)
    .setDescription(`> Seja bem-vindo ao servidor da **zLuuiza**, aqui você pode se comunicar com os nossos jogadores e ficar a par de todas as nossas novidades!`)
    .addField("👥 Membros", `Temos **${memberCount}** atualmente!`, true)
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 4096 }))
    .setColor(colors.none)

    client.channels.cache.get(config.entrada).send(embed)
    
});

client.on("guildMemberRemove", (member) => {

    db.delete(`coins_${member.guild.id}_${member.id}`); 
    db.delete(`banco_${member.guild.id}_${member.id}`); 
    db.delete(`work_${member.guild.id}_${member.id}`); 
    db.delete(`daily_${member.guild.id}_${member.id}`); 
    db.delete(`rob_${member.guild.id}_${member.id}`); 

    console.log(`[ECONOMIA] O ${member.id} saiu do servidor ${member.guild.name}, e teve todos os Status de Economia removidos!`);
});

fs.readdir("./events/", (err, files) => {
    if (err) return console.error("ERRO: " + err)
    files.forEach(file => {

        var eventFunction = require(`./events/${file}`)
        var eventName = file.split(".")[0]

        client.on(eventName, (...args) => eventFunction.run(client, ...args))
    })
});

client.login(config.token)