const Discord = require('discord.js');
const config = require('../config.json');

module.exports.run = async (client, message, args) => {

    client.user.setActivity(config.status, {
    	type: "PLAYING",
    	url: "https://www.twitch.tv/alanzoka"
	})
}